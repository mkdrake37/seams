#!/bin/bash
python3 dostuff.py